var searchData=
[
  ['string_5fsoma_2ecpp',['string_soma.cpp',['../string__soma_8cpp.html',1,'']]],
  ['string_5fsoma_2ehpp',['string_soma.hpp',['../string__soma_8hpp.html',1,'']]]
];
