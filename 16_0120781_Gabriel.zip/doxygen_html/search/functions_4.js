var searchData=
[
  ['test_5fcase',['TEST_CASE',['../testa__string__soma_8cpp.html#ac27a8bc27bc178b77f410d38a864a9c3',1,'testa_string_soma.cpp']]]
];
