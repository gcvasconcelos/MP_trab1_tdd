var searchData=
[
  ['testa_5fsoma_5fstring_5fstdin_2ecpp',['testa_soma_string_stdin.cpp',['../testa__soma__string__stdin_8cpp.html',1,'']]],
  ['testa_5fstring_5fsoma_2ecpp',['testa_string_soma.cpp',['../testa__string__soma_8cpp.html',1,'']]]
];
