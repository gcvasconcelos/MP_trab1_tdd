var searchData=
[
  ['main',['main',['../testa__soma__string__stdin_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'testa_soma_string_stdin.cpp']]]
];
