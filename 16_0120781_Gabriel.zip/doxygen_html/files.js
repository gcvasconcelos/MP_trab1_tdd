var files =
[
    [ "string_soma.cpp", "string__soma_8cpp.html", "string__soma_8cpp" ],
    [ "string_soma.hpp", "string__soma_8hpp.html", "string__soma_8hpp" ],
    [ "testa_soma_string_stdin.cpp", "testa__soma__string__stdin_8cpp.html", "testa__soma__string__stdin_8cpp" ],
    [ "testa_string_soma.cpp", "testa__string__soma_8cpp.html", "testa__string__soma_8cpp" ]
];