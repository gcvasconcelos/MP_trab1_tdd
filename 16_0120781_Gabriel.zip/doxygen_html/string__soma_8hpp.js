var string__soma_8hpp =
[
    [ "soma_string", "string__soma_8hpp.html#ab8331bfa65be3c3ab02052a6588c0c02", null ]
];