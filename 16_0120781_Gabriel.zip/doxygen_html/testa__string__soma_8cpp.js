var testa__string__soma_8cpp =
[
    [ "TEST_CASE", "testa__string__soma_8cpp.html#ac27a8bc27bc178b77f410d38a864a9c3", null ]
];