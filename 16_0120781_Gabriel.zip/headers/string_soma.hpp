/** @file */ 
int soma_string (const char * string_entrada);